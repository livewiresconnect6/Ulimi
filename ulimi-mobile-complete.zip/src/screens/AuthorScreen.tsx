import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import {
  Appbar,
  Avatar,
  Title,
  Paragraph,
  Button,
  Surface,
  Card,
  Chip,
  Text,
} from 'react-native-paper';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAuth } from '../hooks/useAuth';

interface Author {
  id: number;
  displayName: string;
  username: string;
  bio?: string;
  photoURL?: string;
  followersCount: number;
  storiesCount: number;
  totalReads: number;
  isFollowing?: boolean;
}

interface Story {
  id: number;
  title: string;
  description: string;
  genre: string;
  readCount: number;
  likeCount: number;
  estimatedReadTime: number;
  publishedAt: string;
}

const AuthorScreen: React.FC = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { user } = useAuth();
  const [author, setAuthor] = useState<Author | null>(null);
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const authorId = route.params?.id;

  useEffect(() => {
    if (authorId) {
      loadAuthorData();
    }
  }, [authorId]);

  const loadAuthorData = async () => {
    try {
      // Load author profile
      const authorResponse = await fetch(`http://10.0.2.2:5000/api/authors/${authorId}`);
      const authorData = await authorResponse.json();
      setAuthor(authorData);

      // Load author's stories
      const storiesResponse = await fetch(`http://10.0.2.2:5000/api/authors/${authorId}/stories`);
      const storiesData = await storiesResponse.json();
      setStories(storiesData);
    } catch (error) {
      console.error('Error loading author data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadAuthorData();
  };

  const handleFollow = async () => {
    if (!user || !author) return;

    try {
      const response = await fetch(`http://10.0.2.2:5000/api/authors/${author.id}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });

      if (response.ok) {
        setAuthor(prev => prev ? {
          ...prev,
          isFollowing: !prev.isFollowing,
          followersCount: prev.isFollowing ? prev.followersCount - 1 : prev.followersCount + 1
        } : null);
      }
    } catch (error) {
      console.error('Error following author:', error);
    }
  };

  const renderStoryItem = ({ item }: { item: Story }) => (
    <TouchableOpacity onPress={() => navigation.navigate('Read', { id: item.id })}>
      <Card style={styles.storyCard}>
        <Card.Content>
          <Title style={styles.storyTitle} numberOfLines={2}>
            {item.title}
          </Title>
          
          <Paragraph numberOfLines={3} style={styles.storyDescription}>
            {item.description}
          </Paragraph>
          
          <View style={styles.storyMeta}>
            <Chip mode="outlined" compact style={styles.genreChip}>
              {item.genre}
            </Chip>
            <View style={styles.storyStats}>
              <Text style={styles.statText}>👁 {item.readCount}</Text>
              <Text style={styles.statText}>❤️ {item.likeCount}</Text>
              <Text style={styles.statText}>⏱ {item.estimatedReadTime}m</Text>
            </View>
          </View>
          
          <Text style={styles.publishDate}>
            Published {new Date(item.publishedAt).toLocaleDateString()}
          </Text>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  if (loading || !author) {
    return (
      <SafeAreaView style={styles.container}>
        <Appbar.Header style={styles.header}>
          <Appbar.BackAction onPress={() => navigation.goBack()} />
          <Appbar.Content title="Loading..." />
        </Appbar.Header>
        <View style={styles.loadingContainer}>
          <Text>Loading author profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Appbar.Header style={styles.header}>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <Appbar.Content title={author.displayName} titleStyle={styles.headerTitle} />
        <Appbar.Action icon="share-variant" onPress={() => {/* Share author */}} />
      </Appbar.Header>

      <FlatList
        data={stories}
        renderItem={renderStoryItem}
        keyExtractor={(item) => item.id.toString()}
        ListHeaderComponent={
          <View>
            {/* Author Profile Header */}
            <Surface style={styles.profileHeader}>
              <Avatar.Text
                size={100}
                label={author.displayName.charAt(0).toUpperCase()}
                style={styles.authorAvatar}
              />
              
              <Title style={styles.authorName}>{author.displayName}</Title>
              <Paragraph style={styles.authorUsername}>@{author.username}</Paragraph>
              
              {author.bio && (
                <Paragraph style={styles.authorBio}>{author.bio}</Paragraph>
              )}
              
              {/* Author Stats */}
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Title style={styles.statValue}>{author.storiesCount}</Title>
                  <Text style={styles.statLabel}>Stories</Text>
                </View>
                <View style={styles.statItem}>
                  <Title style={styles.statValue}>{author.followersCount}</Title>
                  <Text style={styles.statLabel}>Followers</Text>
                </View>
                <View style={styles.statItem}>
                  <Title style={styles.statValue}>{author.totalReads}</Title>
                  <Text style={styles.statLabel}>Total Reads</Text>
                </View>
              </View>
              
              {/* Follow Button */}
              {user?.id !== author.id && (
                <Button
                  mode={author.isFollowing ? "outlined" : "contained"}
                  onPress={handleFollow}
                  style={styles.followButton}
                >
                  {author.isFollowing ? 'Following' : 'Follow'}
                </Button>
              )}
            </Surface>

            {/* Stories Section Header */}
            <Surface style={styles.storiesHeader}>
              <Title style={styles.storiesTitle}>
                Stories ({stories.length})
              </Title>
            </Surface>
          </View>
        }
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <Surface style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📝</Text>
            <Title style={styles.emptyTitle}>No stories yet</Title>
            <Paragraph style={styles.emptyText}>
              This author hasn't published any stories yet.
            </Paragraph>
          </Surface>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#ff6b35',
  },
  headerTitle: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: {
    paddingBottom: 80,
  },
  profileHeader: {
    margin: 16,
    padding: 24,
    borderRadius: 12,
    elevation: 2,
    alignItems: 'center',
  },
  authorAvatar: {
    backgroundColor: '#ff6b35',
    marginBottom: 16,
  },
  authorName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  authorUsername: {
    fontSize: 16,
    color: '#666',
    marginBottom: 12,
  },
  authorBio: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#e0e0e0',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ff6b35',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
  },
  followButton: {
    paddingHorizontal: 32,
  },
  storiesHeader: {
    margin: 16,
    marginTop: 0,
    padding: 16,
    borderRadius: 12,
    elevation: 2,
  },
  storiesTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  storyCard: {
    margin: 16,
    marginTop: 0,
    elevation: 2,
  },
  storyTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  storyDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  storyMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  genreChip: {
    height: 28,
  },
  storyStats: {
    flexDirection: 'row',
    gap: 12,
  },
  statText: {
    fontSize: 12,
    color: '#666',
  },
  publishDate: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  },
  emptyState: {
    margin: 16,
    padding: 40,
    borderRadius: 12,
    elevation: 2,
    alignItems: 'center',
  },
  emptyEmoji: {
    fontSize: 60,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
});

export default AuthorScreen;