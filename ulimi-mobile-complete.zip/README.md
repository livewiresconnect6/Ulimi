# Ulimi Mobile App - React Native

A complete mobile application for the Ulimi multilingual reading platform, optimized for Android Studio on macOS Ventura 13.7.7.

## Quick Start Guide

### 1. Import into Android Studio
1. Open Android Studio
2. Choose "Import project (Gradle, Eclipse ADT, etc.)"
3. Navigate to the `android` folder and select it
4. Click "OK" and wait for Gradle sync

### 2. Install Dependencies
```bash
npm install
# or
yarn install
```

### 3. Start Metro Bundler
```bash
npx react-native start
```

### 4. Run on Android
- In Android Studio, click the "Run" button (green play icon)
- Or use command: `npx react-native run-android`

## Project Structure

```
ulimi-mobile/
├── android/                 # Android project files
│   ├── app/
│   │   ├── build.gradle     # App-level Gradle config
│   │   └── src/main/        # Android source files
│   ├── build.gradle         # Project-level Gradle config
│   └── gradle.properties    # Gradle properties
├── src/                     # React Native source code
│   ├── screens/            # All app screens
│   │   ├── SplashScreen.tsx
│   │   ├── AuthScreen.tsx
│   │   ├── HomeScreen.tsx
│   │   ├── BrowseScreen.tsx
│   │   ├── LibraryScreen.tsx
│   │   ├── ProfileScreen.tsx
│   │   ├── ReadScreen.tsx
│   │   ├── AudiobookScreen.tsx
│   │   ├── WriteScreen.tsx
│   │   ├── AuthorScreen.tsx
│   │   └── OnboardingScreen.tsx
│   └── hooks/              # Custom React hooks
│       └── useAuth.ts      # Authentication hook
├── App.tsx                 # Main app component
├── index.js               # App entry point
├── app.json              # Expo configuration
├── babel.config.js       # Babel configuration
├── metro.config.js       # Metro bundler config
└── package.json          # Node.js dependencies
```

## Features Included

### ✅ Complete Mobile Screens
- **Splash Screen** - Animated app launch
- **Authentication** - Sign in/up with demo mode
- **Onboarding** - User preference setup
- **Home** - Featured stories and recommendations
- **Browse** - Search and discover stories
- **Library** - Personal reading collection
- **Profile** - User settings and stats
- **Read** - Story reading with translation
- **Audiobook** - Text-to-speech narration
- **Write** - Story creation and publishing
- **Author** - Author profiles and stories

### ✅ Native Features
- **Material Design** - React Native Paper components
- **Navigation** - Bottom tabs + stack navigation
- **Audio** - Text-to-speech integration
- **Translation** - Multi-language support
- **Storage** - Offline data with AsyncStorage
- **Authentication** - User management system

### ✅ Android Studio Integration
- **Gradle Configuration** - Optimized for macOS Ventura
- **Build Scripts** - Ready for compilation
- **Debug Configuration** - Emulator support
- **Resource Management** - Icons and assets

## Backend Connection

The app connects to your Replit backend server:
- **Development**: `http://10.0.2.2:5000` (Android emulator)
- **Production**: Update API URLs in screen files

## Troubleshooting

### Common Issues
1. **Gradle build failed**: Run `cd android && ./gradlew clean`
2. **Metro bundle error**: Run `npx react-native start --reset-cache`
3. **Emulator won't start**: Check HAXM installation in Android Studio

### System Requirements
- macOS Ventura 13.7.7 ✅
- Android Studio Dolphin 2021.3.1+ ✅
- JDK 11 ✅
- Node.js 16+ ✅

## Development Workflow

1. **Make changes** in React Native files
2. **Save files** - Metro will auto-reload
3. **Test on emulator** - See changes instantly
4. **Debug with Chrome** - React Native debugger
5. **Build APK** when ready for testing

## Next Steps

1. Follow `ANDROID_STUDIO_SETUP_MACOS.md` for detailed setup
2. Configure your Replit backend URL in screen files
3. Test all features on Android emulator
4. Customize branding and colors as needed

Your complete Ulimi mobile app is ready to run! 🚀